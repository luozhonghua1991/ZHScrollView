//
//  ViewController.m
//  ScrollViewTest
//
//  Created by Luo on 16/7/5.
//  Copyright © 2016年 Luo. All rights reserved.
//

#import "ViewController.h"
#import "HsScrollView.h"
@interface ViewController ()<HsScrollViewDelegate>
//@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
//@property (weak, nonatomic) IBOutlet UIPageControl *pageControl;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    HsScrollView *scrollView = [HsScrollView HsScrollViewShow];
    scrollView.frame = CGRectMake(37, 50, 300, 150);
//    scrollView.imageNames = @[@"image_0",
//                              @"image_1",
//                              @"image_2",
//                              @"image_3",
//                              @"image_4"
//                              ];
    scrollView.delegate=self;
    scrollView.color = [UIColor grayColor];
    scrollView.currentColor = [UIColor orangeColor];
    scrollView.HsScrollViewBlock = ^(){
        self.view.backgroundColor =[UIColor whiteColor];
    };
//    scrollView.imageNames = @[@"image_0",
//                              @"image_1",
//                              @"image_2",
//                          
//                              ];
    
    scrollView.imageNames = @[@"image_0",
                              @"image_1",
                              @"image_2",
                            
                              
                              ];

    
    [self.view addSubview:scrollView];
    
}
-(void)HsScrollViewClick{
    self.view.backgroundColor =[UIColor blackColor];
}
//    NSInteger count = 5;
//    CGFloat X = self.scrollView.frame.size.width;
//    CGFloat Y = self.scrollView.frame.size.height;
//    for (int i=0; i<count; i++) {
//        UIImageView *imageView =[[UIImageView alloc]initWithFrame:CGRectMake(i*X, 0, X, Y)];
//        imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"image_%d",i]];
//        [self.scrollView addSubview:imageView];
//    }
//    self.scrollView.backgroundColor =[UIColor blueColor];
//    self.scrollView.contentSize = CGSizeMake(count*X, Y);
//    self.scrollView.delegate =self;
////    NSLog(@"%@",self.scrollView.contentSize);
//    //分页功能
//    self.scrollView.pagingEnabled = YES;
//    self.scrollView.showsVerticalScrollIndicator = NO;
//    self.scrollView.showsHorizontalScrollIndicator = NO;
//    self.pageControl.numberOfPages = 5;
//    // Do any additional setup after loading the view, typically from a nib.
//}
//- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
//    NSInteger page = (int)self.scrollView.contentOffset.x/self.scrollView.frame.size.width+0.5;
//
//    self.pageControl.currentPage = page;
//}
//- (void)didReceiveMemoryWarning {
//    [super didReceiveMemoryWarning];
//    // Dispose of any resources that can be recreated.
//}

@end
